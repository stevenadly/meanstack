export interface INavigationUrl {
    text: string;
    url: string;
}