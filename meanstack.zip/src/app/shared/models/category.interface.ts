export interface ICategory {
    id ?:string,
    name?:string,
    description?:string,
    imgSrc ?:string ,
    productCount? :number
}