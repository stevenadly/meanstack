export interface ICartItem{
    id ? : number,
    name? :string,
    imgSrc?  :string,
    category?  : number,
    price? :number,
    quantity ?: number
}