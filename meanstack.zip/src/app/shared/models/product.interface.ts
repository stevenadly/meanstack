export interface IProduct{
    id ? : string,
    name? :string,
    imgSrc?  :string,
    category?  : number,
    price? :number,
    describtion ? : string
}